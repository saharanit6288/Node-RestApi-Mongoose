# Node-RestApi-Mongoose
This is a demo of node rest api with mongoose &amp; mongodb
